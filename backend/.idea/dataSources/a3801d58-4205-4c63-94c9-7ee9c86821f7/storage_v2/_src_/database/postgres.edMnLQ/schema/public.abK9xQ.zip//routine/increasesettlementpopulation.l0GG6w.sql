create function increasesettlementpopulation() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE Settlement SET population = population + 1 WHERE id = NEW.settlement_id;
        RETURN NEW;
    end;
$$;

alter function increasesettlementpopulation() owner to postgres;

