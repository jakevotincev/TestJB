create function person_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    CALL checkPersonHP(NEW.id);
end;
$$;

alter function person_trigger() owner to postgres;

