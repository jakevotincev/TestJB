create procedure checkpersonhp(h_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM People WHERE id = h_id AND health < 0;
END;
$$;

alter procedure checkpersonhp(integer) owner to postgres;

