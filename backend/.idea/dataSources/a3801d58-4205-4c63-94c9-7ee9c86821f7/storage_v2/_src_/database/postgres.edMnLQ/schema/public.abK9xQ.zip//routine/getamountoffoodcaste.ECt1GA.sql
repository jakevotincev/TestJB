create function getamountoffoodcaste(integer) returns bigint
    language sql
as
$$
select sum(food.amount)
from settlement
         join food on settlement.id = food.settlement_id
where settlement.caste_id = $1;
$$;

alter function getamountoffoodcaste(integer) owner to postgres;

