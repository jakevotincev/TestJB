create procedure increasepopulation(settlementid integer)
    language plpgsql
as
$$
declare count integer;
declare casteId integer;
begin
    select count(name) into count from people where people.settlement_id=settlementId and  is_pregnant = true and gestational_age >3;
    select caste_id into casteId from settlement where settlement.id = settlementId;
    while count>0 loop
            insert into people(name,health, strength, money,is_pregnant, gestational_age, settlement_id, caste_id) values ('child',10, 2, 0, false, 0, settlementId, casteId);
            count:= count-1;
        end loop;
end;
$$;

alter procedure increasepopulation(integer) owner to postgres;

