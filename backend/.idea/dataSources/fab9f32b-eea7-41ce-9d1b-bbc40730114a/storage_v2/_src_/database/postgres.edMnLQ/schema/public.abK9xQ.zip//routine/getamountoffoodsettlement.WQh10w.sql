create function getamountoffoodsettlement(settlement integer) returns bigint
    language sql
as
$$
select sum(food.amount)
   from food
   where settlement_id = settlement
$$;

alter function getamountoffoodsettlement(integer) owner to postgres;

