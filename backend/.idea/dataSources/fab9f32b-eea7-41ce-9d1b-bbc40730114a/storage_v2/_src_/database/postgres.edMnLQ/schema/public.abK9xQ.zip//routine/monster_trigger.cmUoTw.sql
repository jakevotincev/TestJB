create function monster_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    CALL checkMonsterHP(NEW.id);
end;
$$;

alter function monster_trigger() owner to postgres;

