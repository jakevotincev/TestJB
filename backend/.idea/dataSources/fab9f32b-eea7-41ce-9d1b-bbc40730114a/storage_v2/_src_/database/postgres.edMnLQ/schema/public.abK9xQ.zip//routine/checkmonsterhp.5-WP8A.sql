create procedure checkmonsterhp(m_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM Monsters WHERE id = m_id AND health < 0;
end;
$$;

alter procedure checkmonsterhp(integer) owner to postgres;

