create function battle_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    CALL changeHealthAfterBattle(NEW.people_id, NEW.monster_id, NEW.damage_to_person, NEW.damage_to_monster);
end;
$$;

alter function battle_trigger() owner to postgres;

