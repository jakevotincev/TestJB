create procedure changehealthafterbattle(h_id integer, m_id integer, damage_p double precision, damage_m double precision)
    language plpgsql
as
$$
BEGIN
    UPDATE People SET health = (health - damage_p) WHERE id = h_id;
    UPDATE Monsters SET health = (health - damage_m) WHERE id = m_id;
END;
$$;

alter procedure changehealthafterbattle(integer, integer, double precision, double precision) owner to postgres;

