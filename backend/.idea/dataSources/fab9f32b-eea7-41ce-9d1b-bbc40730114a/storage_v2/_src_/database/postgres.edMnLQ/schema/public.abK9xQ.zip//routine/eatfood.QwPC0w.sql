create procedure eatfood(s_id integer)
    language plpgsql
as
$$
declare
    ratio double precision;
    c_id integer;
begin
    select caste_id into c_id from settlement where settlement.id = s_id;
    select hunger_ratio into ratio from caste where caste.id = c_id;
    update food set amount = amount - food.amount*ratio/10 where food.settlement_id = s_id;
end;
$$;

alter procedure eatfood(integer) owner to postgres;

